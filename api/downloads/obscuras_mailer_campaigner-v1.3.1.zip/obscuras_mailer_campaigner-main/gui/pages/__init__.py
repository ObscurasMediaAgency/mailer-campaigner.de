"""GUI Pages Package."""
